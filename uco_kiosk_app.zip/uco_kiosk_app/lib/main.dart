import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:uco_kiosk_app/firebase_options.dart';
import 'package:uco_kiosk_app/screens/landing_screen.dart';
import 'package:uco_kiosk_app/screens/login_screen.dart';
import 'package:uco_kiosk_app/screens/profile_screen.dart';
import 'package:uco_kiosk_app/screens/qr_display_screen.dart';
import 'package:uco_kiosk_app/screens/recycling_status_screen.dart';
import 'package:uco_kiosk_app/screens/register_screen.dart';
import 'package:uco_kiosk_app/screens/scan_qr_screen.dart';
import 'package:uco_kiosk_app/screens/reward_screen.dart';
import 'package:uco_kiosk_app/screens/education_screen.dart';
import 'package:uco_kiosk_app/screens/education_quiz_screen.dart';


void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'UCO Recycling Kiosk',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.green),
        useMaterial3: true,
      ),
      initialRoute: '/', // Set the initial route to the landing screen
      routes: {
        '/': (context) => LandingScreen(),
        '/login': (context) => LoginScreen(),
        '/register': (context) => RegisterScreen(),
        '/profile': (context) => ProfileScreen(),
        '/scan_qr': (context) => ScanQrScreen(),
        '/recycling_status_success': (context) => RecyclingStatusScreen.success(),
        '/recycling_status_error': (context) => RecyclingStatusScreen.error(errorMessage: 'Failed to record recycling.'),
        '/display_qr': (context) => QrDisplayScreen(), // Add the new route
        '/reward': (context) => RewardScreen(),
        '/education': (context) => EducationScreen(),
        '/education_quiz': (context) => const EducationQuizScreen(),
      },
    );
  }
}