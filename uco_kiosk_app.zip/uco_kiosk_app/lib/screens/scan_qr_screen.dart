import 'package:flutter/material.dart';

class ScanQrScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Scan QR Code')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(30.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Icon(Icons.qr_code_scanner, size: 100, color: Colors.green),
              SizedBox(height: 30),
              Text(
                'Please present your QR code to the recycling kiosk scanner.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 18),
              ),
              SizedBox(height: 20),
              Text(
                '(Make sure the scanner can clearly see the code on your screen.)',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 14, color: Colors.grey),
              ),
              // You might add a small preview of the user's QR code here if needed
            ],
          ),
        ),
      ),
    );
  }
}