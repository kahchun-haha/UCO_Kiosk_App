import 'package:flutter/material.dart';

class RecyclingStatusScreen extends StatelessWidget {
  final bool isSuccess;
  final double? amount;
  final int? pointsEarned;
  final String? errorMessage;

  const RecyclingStatusScreen.success({
    this.amount,
    this.pointsEarned,
  })  : isSuccess = true,
        errorMessage = null;

  const RecyclingStatusScreen.error({this.errorMessage})
      : isSuccess = false,
        amount = null,
        pointsEarned = null;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Recycling Status')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(30.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              if (isSuccess) ...[
                Icon(Icons.check_circle_outline, size: 100, color: Colors.green),
                SizedBox(height: 20),
                Text('Recycling Recorded Successfully!', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                SizedBox(height: 10),
                if (amount != null) Text('Amount Recycled: $amount liters', style: TextStyle(fontSize: 16)),
                if (pointsEarned != null) Text('Points Earned: +$pointsEarned', style: TextStyle(fontSize: 16)),
                SizedBox(height: 30),
                ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context); // Go back to the profile screen for now
                  },
                  child: Text('Done'),
                ),
              ] else ...[
                Icon(Icons.error_outline, size: 100, color: Colors.red),
                SizedBox(height: 20),
                Text('Error Recording Recycling', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                SizedBox(height: 10),
                if (errorMessage != null) Text(errorMessage!, textAlign: TextAlign.center),
                SizedBox(height: 30),
                ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context); // Go back to the previous screen
                  },
                  child: Text('Try Again'),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}