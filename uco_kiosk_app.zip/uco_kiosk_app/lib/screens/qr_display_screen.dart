import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:uco_kiosk_app/services/auth_service.dart';

class QrDisplayScreen extends StatefulWidget {
  const QrDisplayScreen({super.key});

  @override
  _QrDisplayScreenState createState() => _QrDisplayScreenState();
}

class _QrDisplayScreenState extends State<QrDisplayScreen> {
  final AuthService _authService = AuthService();
  String? _qrCodeData;

  @override
  void initState() {
    super.initState();
    _loadQrCode();
  }

  Future<void> _loadQrCode() async {
    User? user = _authService.getCurrentUser();
    if (user != null) {
      DocumentSnapshot? userData = await _authService.getUserData(user.uid);
      if (userData != null && userData.exists) {
        setState(() {
          _qrCodeData = userData.get('qrCode');
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Present QR Code')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              'Present this QR code to the kiosk scanner',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 18),
            ),
            SizedBox(height: 20),
            if (_qrCodeData != null)
              QrImageView(
                data: _qrCodeData!,
                version: QrVersions.auto,
                size: 300.0,
              )
            else
              Text('Loading QR Code...'),
            SizedBox(height: 20),
            Text(
              'For easier scanning, please ensure your device brightness is turned up.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 14, color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }
}