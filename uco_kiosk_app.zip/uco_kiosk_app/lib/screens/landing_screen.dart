import 'package:flutter/material.dart';

class LandingScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(32.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Image.asset('assets/images/UMinyak.png', height: 150),
              SizedBox(height: 16),
              Text(
                'UMinyak',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.green[700], // Adjust color
                ),
              ),
              SizedBox(height: 24),

              // Headline/Tagline
              Text(
                'Recycle Your Used Cooking Oil, Earn Rewards!',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 18,
                  color: Colors.black87,
                ),
              ),
              SizedBox(height: 16),

              // Brief Description
              Text(
                'Join our community to easily recycle your used cooking oil at designated kiosks. Earn points, track your impact, and contribute to a sustainable future.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.black54,
                ),
              ),
              SizedBox(height: 40),

              // Login Button
              ElevatedButton(
                onPressed: () {
                  Navigator.pushReplacementNamed(context, '/login');
                },
                style: ElevatedButton.styleFrom(
                  padding: EdgeInsets.symmetric(vertical: 16),
                  backgroundColor: Colors.green, // Adjust color
                  textStyle: TextStyle(fontSize: 18),
                ),
                child: Text(
                  'Log In',
                  style: TextStyle(color: Colors.white),
                ),
              ),
              SizedBox(height: 16),

              // Register Button
              OutlinedButton(
                onPressed: () {
                  Navigator.pushReplacementNamed(context, '/register');
                },
                style: OutlinedButton.styleFrom(
                  padding: EdgeInsets.symmetric(vertical: 16),
                  side: BorderSide(color: Colors.green, width: 2), // Adjust color
                  textStyle: TextStyle(fontSize: 18),
                ),
                child: Text(
                  'Register',
                  style: TextStyle(color: Colors.green), // Adjust color
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}