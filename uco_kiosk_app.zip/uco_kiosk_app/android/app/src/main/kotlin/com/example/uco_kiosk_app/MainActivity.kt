package com.example.uco_kiosk_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
